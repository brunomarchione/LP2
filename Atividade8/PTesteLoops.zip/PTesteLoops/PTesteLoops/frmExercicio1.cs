﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            int quantidade = 0;
            foreach (char caractere in rchtxtFrase.Text)
            {
                if (char.IsWhiteSpace(caractere))
                    quantidade++;
            }
            if (quantidade > 0)
                MessageBox.Show($"Existem {quantidade} espaços em branco na frase.");
            else
                MessageBox.Show("Nenhum espaço em branco foi encontrado na frase.");
        }

        private void btnRetepeR_Click(object sender, EventArgs e)
        {
            string texto = rchtxtFrase.Text;
            int contador = 0, index = 0;
            while (index < texto.Length)
            {
                if (char.ToUpper(texto[index]) == 'R')
                {
                    contador++;
                }
                index++;
            }
            if (contador == 0)
                MessageBox.Show("A frase não possui nenhuma letra R");
            else
                MessageBox.Show("A frase possui " + contador + " letras R");
        }

        private void btnRepeteLetra_Click(object sender, EventArgs e)
        {
            int contarLetras = 0;
            for (int i = 0; i < rchtxtFrase.Text.Length - 1; i++)
            {
                if (char.ToUpper(rchtxtFrase.Text[i]) == char.ToUpper(rchtxtFrase.Text[i + 1]))
                {
                    contarLetras++;
                }
            }
            if (contarLetras == 0)
                MessageBox.Show("A frase não possui pares de letras consecutivas iguais.");
            else
                MessageBox.Show("A frase possui " + contarLetras + " pares de letras consecutivas iguais.");
        }
    }
}
