﻿namespace PTesteLoops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblExplicacao = new System.Windows.Forms.Label();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnEspaco = new System.Windows.Forms.Button();
            this.btnRetepeR = new System.Windows.Forms.Button();
            this.btnRepeteLetra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblExplicacao
            // 
            this.lblExplicacao.AutoSize = true;
            this.lblExplicacao.Location = new System.Drawing.Point(12, 9);
            this.lblExplicacao.Name = "lblExplicacao";
            this.lblExplicacao.Size = new System.Drawing.Size(292, 16);
            this.lblExplicacao.TabIndex = 0;
            this.lblExplicacao.Text = "Digite uma frase com no máximo 100 caracteres";
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(15, 28);
            this.rchtxtFrase.MaxLength = 101;
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(465, 122);
            this.rchtxtFrase.TabIndex = 1;
            this.rchtxtFrase.Text = "";
            // 
            // btnEspaco
            // 
            this.btnEspaco.Location = new System.Drawing.Point(15, 157);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(151, 64);
            this.btnEspaco.TabIndex = 2;
            this.btnEspaco.Text = "Quantos epaçoes em branco existem na frase";
            this.btnEspaco.UseVisualStyleBackColor = true;
            this.btnEspaco.Click += new System.EventHandler(this.btnEspaco_Click);
            // 
            // btnRetepeR
            // 
            this.btnRetepeR.Location = new System.Drawing.Point(167, 157);
            this.btnRetepeR.Name = "btnRetepeR";
            this.btnRetepeR.Size = new System.Drawing.Size(156, 64);
            this.btnRetepeR.TabIndex = 3;
            this.btnRetepeR.Text = "Quantas vezes o \"R\" aparece";
            this.btnRetepeR.UseVisualStyleBackColor = true;
            this.btnRetepeR.Click += new System.EventHandler(this.btnRetepeR_Click);
            // 
            // btnRepeteLetra
            // 
            this.btnRepeteLetra.Location = new System.Drawing.Point(329, 157);
            this.btnRepeteLetra.Name = "btnRepeteLetra";
            this.btnRepeteLetra.Size = new System.Drawing.Size(151, 64);
            this.btnRepeteLetra.TabIndex = 4;
            this.btnRepeteLetra.Text = "Quantas vezes repete duas letras iguais consecutivas";
            this.btnRepeteLetra.UseVisualStyleBackColor = true;
            this.btnRepeteLetra.Click += new System.EventHandler(this.btnRepeteLetra_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 258);
            this.Controls.Add(this.btnRepeteLetra);
            this.Controls.Add(this.btnRetepeR);
            this.Controls.Add(this.btnEspaco);
            this.Controls.Add(this.rchtxtFrase);
            this.Controls.Add(this.lblExplicacao);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblExplicacao;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.Button btnRetepeR;
        private System.Windows.Forms.Button btnRepeteLetra;
    }
}