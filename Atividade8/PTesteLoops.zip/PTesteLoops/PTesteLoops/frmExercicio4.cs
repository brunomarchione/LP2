﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void mskGratificacao_Validated(object sender, EventArgs e)
        {
        }

        private void mskSalario_Validated(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double B = 0, C = 0, D = 0, bonus;
            double salario, salarioBruto, gratificacao, producao;

            if (!double.TryParse(mskSalario.Text, out salario))
            {
                MessageBox.Show("Digite um valor válido para o salário");
                return;
            }

            if (!double.TryParse(mskGratificacao.Text, out gratificacao))
            {
                MessageBox.Show("Digite um valor válido para a gratificação");
                return;
            }

            if (!double.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Digite um valor válido para Produção");
                return;
            }

            if (producao >= 150)
            {
                B = 1;
                C = 1;
                D = 1;
            }
            else if (producao >= 120)
            {
                B = 1;
                C = 1;
            }
            else if (producao >= 100)
            {
                B = 1;
            }

            salarioBruto = salario + (salario * ((0.05 * B) + (0.1 * C) + (0.1 * D))) + gratificacao;

            if (gratificacao != 0 && producao >= 150)
            {
                txtSalarioBruto.Text = salarioBruto.ToString("N2");
            }
            else if (salarioBruto >= 7000)
            {
                salarioBruto = 7000.00;
                txtSalarioBruto.Text = salarioBruto.ToString("N2");
            }
            else
            {
                txtSalarioBruto.Text = salarioBruto.ToString("N2");
            }
        }
    }
}
