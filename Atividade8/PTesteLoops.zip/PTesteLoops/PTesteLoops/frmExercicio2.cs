﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnGerar_Click(object sender, EventArgs e)
        {
            double H = 1.0;
            if (int.TryParse(txtN.Text, out int numero) && numero > 0)
            {
                for (int i = 2; i <= numero; i++)
                    H += 1.0 / i;
                MessageBox.Show($"O número H é {H}");
            }
            else
                MessageBox.Show($"Digite um número válido!");

        }
    }
}
