﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            lboxNomes.Items.Clear();

            string[] nomes = new string[7];
            int[] tamanho = new int[7];

            for (int i = 0; i < nomes.Length; i++)
                nomes[i] = Interaction.InputBox($"Digite o {i + 1}º nome", "Entrada de dados");

            for (int k = 0; k < 7; k++)
            {
                tamanho[k] = 0;
                for (int j = 0; j < nomes[k].Length; j++)
                {
                    if (nomes[k][j] != ' ')
                    {
                        tamanho[k]++;
                    }
                }
                lboxNomes.Items.Add("O nome: " + nomes[k] + " tem " + tamanho[k] + " caracteres");
            }
        }
    }
}
