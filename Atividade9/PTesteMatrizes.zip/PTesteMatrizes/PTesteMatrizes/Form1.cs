﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;


namespace PTesteMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1} número", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Insira um valor válido");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";

            foreach (int x in vetor)
                auxiliar += x + "\n";

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            string alunos;
            alunos = "";

            ArrayList nomes = new ArrayList() {"Ana","André","Débora","Fátima","João","Janete","Otávio","Marcelo","Pedro","Thais"};

            nomes.Remove("Otávio");

            foreach (string y in nomes)
                alunos += y + "\n";

            MessageBox.Show(alunos);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[] mediaAlunos = new double[20];
            string auxiliar;

            Double[,] notas = new Double[20, 3];

            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {nota + 1} do aluno {aluno + 1}", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Insira um valor válido");
                        nota--;
                    }
                }

                mediaAlunos[aluno] = (notas[aluno, 0] + notas[aluno, 1] + notas[aluno, 2]) / 3;
            }

            auxiliar = "";

            int al = 1;

            foreach (double y in mediaAlunos)
            {
                auxiliar += "Aluno " + al + ":" + " Média: " + y.ToString("F2") + "\n";
                al += 1;
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 FrmExercicio4 = new frmExercicio4();
            FrmExercicio4.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 FrmExercicio5 = new frmExercicio5();
            FrmExercicio5.Show();
        }
    }
}
