﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            Char[,] respostas = new Char[8, 10];
            char[] gabarito = new char[10] { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            string gabaritoString = "Gabarito: A B C D E A B C D E";
            string auxiliar = "";
            string alunoImprime = "";
            int acertos = 0;

            lboxResultado.Items.Clear();

            lboxResultado.Items.Add(gabaritoString);

            for (int aluno = 0; aluno < 8; aluno++)
            {
                alunoImprime += "Aluno " + (aluno + 1) + ": ";
                for (int questao = 0; questao < 10; questao++)
                {
                    auxiliar = Interaction.InputBox($"Digite a resposta da questão {questao + 1} do aluno {aluno + 1}", "Entrada de dados");
                    if (!char.TryParse(auxiliar, out respostas[aluno, questao]) || !"ABCDE".Contains(auxiliar))
                    {
                        MessageBox.Show("Insira um valor válido");
                        questao--;
                    }
                    else
                    {
                        alunoImprime += " " + respostas[aluno, questao];
                        if (respostas[aluno, questao] == gabarito[questao])
                            acertos++;
                    }
                }
                alunoImprime += " - " + acertos + "   Respostas corretas!";
                lboxResultado.Items.Add(alunoImprime);
                alunoImprime = "";
                acertos = 0;
            }
        }
    }
}
