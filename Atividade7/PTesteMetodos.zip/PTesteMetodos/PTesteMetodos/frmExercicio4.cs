﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {
            string texto = rchtxtFrase.Text;
            int contador = 0, index = 0;
            while (index < texto.Length)
            {
                if (char.IsNumber(texto[index]))
                {
                    contador++;
                }
                index++;
            }
            MessageBox.Show("A frase possui " + contador + " Números");
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int posicao = -1;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i;
                    break;
                }
            }
            if (posicao != -1)
            {
                MessageBox.Show("Primeiro caracter em branco está na posição " + (posicao + 1));
            }
            else
            {
                MessageBox.Show("Nenhum caracter em branco foi encontrado no texto");
            }
        }

        private void btnCaracter_Click(object sender, EventArgs e)
        {
            int contarLetras = 0;
            foreach (char caractere in rchtxtFrase.Text)
            {
                if (char.IsLetter(caractere))
                {
                    contarLetras++;
                }
            }
            MessageBox.Show("A frase possui " + contarLetras + " letras alfabéticas");
        }
    }
}
