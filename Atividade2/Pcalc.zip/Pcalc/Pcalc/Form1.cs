﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado;

        public Form1()
        {
            InitializeComponent();
        }


        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }


        private void txtNumero1_Validated(object sender, EventArgs e)
        {
        
        }
        
        private void txtNumero2_Validated(object sender, EventArgs e)
        {
   
        }
         

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
            txtResultado.Text = Resultado.ToString();
        }
         
        private void btnSub_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
            txtResultado.Text = Resultado.ToString();
        }


        private void btnMult_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
            txtResultado.Text = Resultado.ToString();
        }


        private void btnDiv_Click(object sender, EventArgs e)
        {
            if(Numero2 == 0)
            {
                MessageBox.Show("Não existe divisão por Zero!");
                txtNumero2.Focus();
            }
            else
            {
                Resultado = Numero1 / Numero2;
                txtResultado.Text = Resultado.ToString();
            }
           
        }

        private void txtNumero1_Validated_1(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out Numero1))
            {
                MessageBox.Show("Número 1 é Inválido");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated_1(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out Numero2))
            {
                MessageBox.Show("Número 2 é Inválido");
                txtNumero2.Focus();
            }
        }

        private void txtResultado_Validated_1(object sender, EventArgs e)
        {
            if (!double.TryParse(txtResultado.Text, out Resultado))
            {
                MessageBox.Show("Resultado Inválido!");
                txtResultado.Focus();
            }
        }

        private void txtResultado_Validated(object sender, EventArgs e)
        {
   
        }


        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você realmente deseja sair", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }

    }
}
