﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PAluno
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            Double[,] nota = new double[9, 3];
            string auxiliar;
            string alunoImprime = "";
            double media = 0;
            double mediaTotal = 0;
            double notaAux = 0;
            int contProfessor = 1;

            lstbxResultado.Items.Clear();

            for (int aluno = 0; aluno < 9; aluno++)
            {
                alunoImprime += "Aluno: " + (aluno + 1) + " ";
                for (int professor = 0; professor < 3; professor++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota do professor {contProfessor} para o aluno {aluno + 1}", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out nota[aluno, professor]))
                    {
                        MessageBox.Show("Insira um valor válido");
                        professor--;
                    }
                    else if (nota[aluno, professor] < 0 || nota[aluno, professor] > 10)
                    {
                        MessageBox.Show("Insira um valor válido");
                        professor--;
                    }
                    else
                    {
                        notaAux = nota[aluno, professor];
                        alunoImprime += "Nota professor " + (professor + 1) + ":" + notaAux.ToString("F2") + " ";
                        media += nota[aluno, professor];
                        contProfessor++;
                    }
                }
                media = media / 3;
                mediaTotal += media;
                alunoImprime += "Media: " + media.ToString("F2");
                lstbxResultado.Items.Add(alunoImprime);
                alunoImprime = "";
                media = 0;
                contProfessor = 1;
            }

            mediaTotal = mediaTotal / 9;
            alunoImprime = "------------------------------";
            lstbxResultado.Items.Add(alunoImprime);
            alunoImprime = "Media Geral Alunos: " + mediaTotal.ToString("F2");
            lstbxResultado.Items.Add(alunoImprime);
        }
    }
}
