﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PDisaster0030482323007
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=PC-BRUNO\\SQLEXPRESS01;Initial Catalog=LP2;Integrated Security=True;Encrypt=False");
                conexao.Open();
            }
            catch (SqlException ex) 
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Outros erros =/" + ex.Message);
            }

        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                //Application.OpenForms["frmSobre"].Activate();
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre obj2 = new frmSobre();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void CadastroCidades_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCidade>().Count() > 0)
            {
                //Application.OpenForms["frmCidade"].Activate();
                Application.OpenForms["frmCidade"].BringToFront();
            }
            else
            {
                frmCidade obj2 = new frmCidade();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void CadastroTipoDeEventos_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmTipo>().Count() > 0)
            {
                //Application.OpenForms["frmTipo"].Activate();
                Application.OpenForms["frmTipo"].BringToFront();
            }
            else
            {
                frmTipo obj2 = new frmTipo();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void CadastroEventos_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEvento>().Count() > 0)
            {
                //Application.OpenForms["frmEvento"].Activate();
                Application.OpenForms["frmEvento"].BringToFront();
            }
            else
            {
                frmEvento obj2 = new frmEvento();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }
    }
}
